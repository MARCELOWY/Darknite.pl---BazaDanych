addappid(1229490)
addappid(1229491,0,"347634f48592b176da96c10b8afe6898527aa5c218d89930f9d6e5b6d5e7c8ba")
setManifestid(1229491,"6093621263526928435")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]