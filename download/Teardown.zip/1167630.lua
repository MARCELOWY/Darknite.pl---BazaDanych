-- Tea​‌‌​​​‌‌​​‌‌​​​​​‌‌​​​‌‌​‌‌​​​‌‌​​‌‌​‌​​​​‌‌​‌‌‌​‌‌​​‌‌​​​‌‌​‌​‌​‌‌​​​‌‌​​‌‌​‌‌​​‌‌​​​‌​​​‌‌​‌‌‌​‌‌​​​‌​​​‌‌​‌​​​​‌‌​​​‌​​‌‌​​‌​rdown
-- AppID 1167630 | Generated on 2026-02-04 23:39 UTC | openlua.cloud
-- Note: This game supports Steam Workshop content

-- Main Application
addappid(1167630, 1, "ab0df752844fd0c6a4d4275dc2f775619b833994f46509037bc18f01c9fe97f9")

-- Content Depots (1)
addappid(1167634, 1, "4e402173b44873473aa98965b7075111059716ebc005137bc93e3e645fe13027") -- Teardown Depot

-- DLCs with Content (4)
addappid(2657060, 1, "e0d5e7a570d792711265ff7532a2dc8bce4648837e8d86c94dcf77f531c09baf") -- Teardown Folkrace
addappid(2657100, 1, "5df4828df3d5422b27c221a29b70af3f0a032c14f71c632237047fb4b2ab2644") -- Teardown The Greenwash Gambit
addappid(2657080, 1, "204a8120beb5167f417969cac2724a24b5a1b35019dc45f94cca8fc986512185") -- Teardown Quilez R0113R Robot
addappid(2657050, 1, "74eef5a7cdbac71c450a5d63ef57f193af7d4f1fd9717a88ece34eb6d9be7c3c") -- Teardown Time Campers

-- DLCs without Dedicated Depots (1)
addappid(2657070) -- Teardown Season Pass
