-- My Win​​‌‌​​‌​​​‌‌​​​‌​‌‌​​​​‌​​‌‌‌​​‌​​‌‌‌​​​​​‌‌​‌​​​​‌‌​​‌‌​‌‌​​​​‌​​‌‌‌​​‌​​‌‌​​‌​​​‌‌​‌‌​​‌‌​​‌‌​​‌‌​​‌​​​​‌‌​‌​​​​‌‌​‌‌‌​​‌‌​‌​​ter Car
-- AppID 4164420 | Generated on 2026-01-01 01:56 UTC | openlua.cloud

-- Main Application
addappid(4164420)

-- Content Depots (1)
addappid(4164421, 1, "25786818231B18D0C50CADB12BE7D574140D7DE03EDEBBEA0FDEB17C8AC49FB7") -- My Winter Car - Windows
