addappid(1928870)
addappid(1928871, 1, "77e4ff98428ea4b5db197ad78037b2c0b2ab66399777fa157d1bc84e99fdb289")
setManifestid(1928871, "4592995720016410867", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]