addappid(1672970)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1672971,0,"b42295e44d98b2ed35338c9f96b4c65ad99a839023e9e4ddef8e19ddc7addac4")
setManifestid(1672971,"4325055371153456789")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]