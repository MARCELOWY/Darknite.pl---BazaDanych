-- Gang ​​‌‌​‌‌​​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌‌​​‌‌​​‌​​​‌‌​​‌​​​‌‌​​​‌​​‌‌​​​​‌​‌‌​​‌‌​​​‌‌​​‌​​​‌‌​‌​‌​‌‌​​‌‌​​​‌‌​‌‌​​​‌‌​​‌​​​‌‌​‌‌​​​‌‌​​‌‌Beasts
-- AppID 285900 | Generated on 2026-02-10 02:29 UTC | openlua.cloud
-- Note: This game supports Steam Workshop content

-- Main Application
addappid(285900, 1, "d5a3784e280306f122da4ab0a05de37374dbdb0f652b5aab6d614a145ee4ff28")

-- Content Depots (3)
addappid(285901, 1, "417b624d1798155e5d9bd1fe0e54fb15f6c418fe23caacc03e76866a6ef5d2f6") -- Gang Beasts (Windows)
addappid(285902, 1, "0c325cb5864b8f034bc692fa8a2741674d1b30c51d51acb91ff331498133435c") -- Gang Beasts (Mac)
addappid(285903, 1, "47dbec3990eb35d1b9f0e30306b05e5de90de70b1e134a4bbf651ca195de085f") -- Gang Beasts (Linux)
