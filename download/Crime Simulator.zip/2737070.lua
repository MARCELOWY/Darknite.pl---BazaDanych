-- Crime S​‌‌​​‌‌​​‌‌​​​‌​​‌‌​​‌​‌​​‌‌‌​​‌​​‌‌‌​​​​​‌‌‌​​​​​‌‌‌​​​​​‌‌​‌​​​​‌‌​​​‌​‌‌​​​​‌​​‌‌​‌​‌​‌‌​​‌‌​​​‌‌‌​​‌​​‌‌‌​​‌​‌‌​​‌​‌​​‌‌‌​​​imulator
-- AppID 2737070 | Generated on 2026-01-03 19:22 UTC | openlua.cloud

-- Main Application
addappid(2737070)

-- Content Depots (1)
addappid(2737071, 1, "36e272c2274c8d6dbf4a697d1faa618de36bbacf8439215d60cca4350601aedb") -- Crime Simulator - Content
