-- Cheap C​​‌‌​‌​‌​​‌‌​​‌​​‌‌​​​‌‌​‌‌​​‌​‌​​‌‌​‌‌​​‌‌​​‌​​​‌‌​​‌‌​​​‌‌​‌​​​‌‌​​​‌​​​‌‌​‌‌​​​‌‌​‌​‌​‌‌​​​​‌​​‌‌​‌‌‌​​‌‌​‌​​​‌‌​​‌​​​​‌‌​‌‌‌ar Repair
-- AppID 2904040 | Generated on 2026-06-06 13:58 UTC | openlua.cloud

-- Main Application
addappid(2904040)

-- Content Depots (1)
addappid(2904041, 1, "5f2fc48115edd9e7bfc1546f9dc43c8d900013aaf3d4f5035fb69ff28899f050") -- Cheap Car Repair - Content
